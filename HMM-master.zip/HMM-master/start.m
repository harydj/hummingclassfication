cd "~/Dropbox/school code/PS"
baum_welch_environment
gama = gama(obs, pi, a, miu, sigma, b, c, alfa, beta)
